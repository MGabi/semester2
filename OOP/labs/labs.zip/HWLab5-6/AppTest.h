//
// Created by mgabi on 05.04.2018.
//
#pragma once

class AppTest {
public:
    explicit AppTest() = default;
    void runAll();
    void testDynamicVector();
    void testTutorial();

    void testPlaylist();

    void testRepository();

    void testController();
};